﻿namespace CompressionStocking.BusinessLogic
{
    public interface IPressureChangedListener
    {
        void PressureChanged();
    }
}
