﻿namespace CompressionStocking.BusinessLogic
{
    public interface OnOffDevice
    {
        void TurnOn();
        void TurnOff();
    }
}
