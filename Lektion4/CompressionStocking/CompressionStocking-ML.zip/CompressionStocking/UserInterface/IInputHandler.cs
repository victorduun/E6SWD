﻿namespace CompressionStocking.UserInterface
{
    public interface IInputHandler
    {
        void HandleStartButtonPushed();
        void HandleStopButtonPushed();
    }
}
