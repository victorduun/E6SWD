﻿namespace CompressionStocking.UserInterface
{
    public interface ICompressionStocking
    {
        void StartCompression();
        void StartDecompression();
    }
}
